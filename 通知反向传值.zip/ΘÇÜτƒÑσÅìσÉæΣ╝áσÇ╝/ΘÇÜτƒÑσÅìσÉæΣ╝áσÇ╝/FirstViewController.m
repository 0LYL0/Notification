//
//  FirstViewController.m
//  通知反向传值
//
//  Created by  刘雅兰 on 17/11/1.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//

#import "FirstViewController.h"
#import "SecondViewController.h"

@interface FirstViewController ()

@property (strong,nonatomic)UILabel *label;
@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UIButton *nextBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 100, 100, 100)];
    [nextBtn addTarget:self action:@selector(nextBtnClick:) forControlEvents:UIControlEventTouchDown];
    [nextBtn setTitle:@"nextVC" forState:UIControlStateNormal];
    nextBtn.backgroundColor = [UIColor cyanColor];
    [self.view addSubview:nextBtn];
    
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 300, self.view.bounds.size.width, 50)];
    label.backgroundColor = [UIColor redColor];
    [self.view addSubview:label];
    self.label = label;
    
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getValueFromSecondVC:) name:@"ViewControllerNotificationCenter" object:nil];
    
    
    
    
    // Do any additional setup after loading the view from its nib.
}


-(void)nextBtnClick:(UIButton *)nextBtn{
    
    SecondViewController *secondVC = [[SecondViewController alloc]init];
    
    [self presentViewController:secondVC animated:YES completion:nil];
    
    
}


-(void)getValueFromSecondVC:(NSNotification *)notification{
    
    
    self.label.text = notification.object;
    
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
