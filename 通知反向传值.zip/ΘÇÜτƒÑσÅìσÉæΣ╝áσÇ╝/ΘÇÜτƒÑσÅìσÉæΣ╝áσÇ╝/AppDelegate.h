//
//  AppDelegate.h
//  通知反向传值
//
//  Created by  刘雅兰 on 17/11/1.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

